#ifndef boost_blasbindings_blasbindings_hpp
#define boost_blasbindings_blasbindings_hpp

#include <boost/numeric/bindings/blas/blas1.hpp>
#include <boost/numeric/bindings/blas/blas2.hpp>
#include <boost/numeric/bindings/blas/blas3.hpp>


#endif // boost_blasbindings_blasbindings_hpp
