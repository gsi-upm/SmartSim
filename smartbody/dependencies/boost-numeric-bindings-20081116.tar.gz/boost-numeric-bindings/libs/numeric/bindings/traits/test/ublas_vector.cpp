#include <boost/numeric/ublas/vector.hpp>
#include <boost/numeric/bindings/traits/vector_traits.hpp>

int main()
{
  /*
  using namespace boost::numeric::ublas ;
  using namespace boost::numeric::bindings::traits ;

  vector< double > v( 10 ) ;  
  
  if ( vector_storage( v ) != & v[0] ) return 1 ;
  if ( vector_size( v ) != 10 )        return 2 ;
  if ( vector_stride( v ) != 1 )       return 3 ;
  */
  return 0 ;
}
